package com.digitalhouse.checkout.service;


import com.digitalhouse.checkout.model.dto.Product;

public interface IProductService {
	
	
	public Product getProduct(String id);

}
